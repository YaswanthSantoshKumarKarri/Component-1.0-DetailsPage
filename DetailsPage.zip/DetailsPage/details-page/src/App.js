import './App.css';
import DetailsPage from './Component/DetailsPage/DetailsPage';

function App() {
  return (
    <div className="App">
      <DetailsPage/>
    </div>
  );
}

export default App;
